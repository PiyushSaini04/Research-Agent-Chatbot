﻿# AI Investment Research Agent

## Overview

This project is an AI-powered investment research assistant built with Next.js, TypeScript, LangGraph, and Google Gemini. Users can enter a public company name and receive a structured investment opinion with supporting evidence, market context, and a final report.

The system resolves the company ticker, gathers company, financial, news, competitor, risk, valuation, and macroeconomic signals in parallel, then synthesizes everything into a final INVEST / PASS recommendation.

## Assignment Bundle

A downloadable ZIP bundle of this assignment is available here:

- https://github.com/PiyushSaini04/Research-Agent-Chatbot/raw/main/ai-investment-agent-assignment.zip

This package contains the project source code, documentation, and the updated README.

## What It Does

- Accepts a company name or ticker input
- Resolves the correct company and ticker via multiple providers
- Runs a multi-agent research pipeline
- Streams live progress updates while research is in progress
- Generates a final investment report with recommendation, evidence score, confidence, rationale, and key drivers
- Stores research sessions and saved reports in Supabase

## How to Run It

### Prerequisites

- Node.js 20+
- npm
- Access to the required API keys below

### Environment Variables

Create a .env.local file in the project root with values similar to:

```env
GOOGLE_GEMINI_API_KEY=your_gemini_key
FMP_API_KEY=your_fmp_key
FINNHUB_API_KEY=your_finnhub_key
TAVILY_API_KEY=your_tavily_key
RAPIDAPI_KEY=your_rapidapi_key
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
```

### Installation

```bash
npm install
```

### Development Server

```bash
npm run dev
```

Then open http://localhost:3000

### Build and Test

```bash
npm run build
npm run test
```

## How It Works

The application is organized around a LangGraph-based research workflow:

1. Planner Agent
   - Resolves the company name to a ticker and basic metadata
   - Uses cached Supabase company data first, then falls back to external providers

2. Parallel Research Agents
   - Company Agent: company profile and business context
   - Financial Agent: financial statements, margins, valuation, liquidity
   - News Agent: recent market and company news
   - Competition Agent: peer and competitive positioning
   - Risk Agent: operational and market risks
   - Valuation Agent: valuation estimates and fair-value view
   - Macroeconomic Agent: sector and macroeconomic outlook

3. Aggregator and Data Quality
   - Combines evidence into a compact context summary
   - Scores data completeness and flags missing information

4. Decision and Report Agents
   - Produces an evidence-based recommendation
   - Writes a final markdown report with rationale and supporting points

The frontend streams progress updates over SSE while the backend pipeline runs, giving users a near-real-time view of the analysis.

## Key Decisions and Trade-offs

### What was chosen

- LangGraph for agent orchestration because it provides a clear stateful workflow and extensibility
- Gemini for reasoning and report generation because it can synthesize multi-source context well
- Parallel research agents to reduce latency and improve responsiveness
- Supabase for session persistence, authentication, and saved reports

### Trade-offs

- The app favors speed and flexibility over deep proprietary financial modeling
- It uses multiple external providers to improve coverage, but this introduces some dependency on API availability
- The current decision logic is robust but intentionally lightweight for a first-version research assistant

### What was left out

- Real-time portfolio context and watchlist tracking
- Formal backtesting or historical signal evaluation
- Advanced risk simulation and scenario modeling
- Deep accounting reconciliation and custom financial statement parsing

## Example Runs

Representative examples of the system’s output style are shown below. Actual values will vary based on live market data and API availability.

### Example 1: Apple

- Recommendation: PASS
- Confidence: 72%
- Evidence Score: 78/100
- Key Drivers: premium valuation, slower growth, strong balance sheet

### Example 2: NVIDIA

- Recommendation: INVEST
- Confidence: 81%
- Evidence Score: 85/100
- Key Drivers: AI demand tailwinds, strong margin profile, improving earnings momentum

### Example 3: Tesla

- Recommendation: PASS
- Confidence: 69%
- Evidence Score: 74/100
- Key Drivers: valuation concerns, competitive pressures, execution risk

## What I Would Improve With More Time

- Add stronger caching and retrieval for repeated company lookups
- Improve data normalization across provider formats
- Add a better explanation layer for each recommendation component
- Expand the scoring model with historical backtesting and scenario simulations
- Add richer UI for charts, sources, and evidence breakdowns

## Project Structure

- src/app: Next.js app routes and UI pages
- src/agents: research agents and LangGraph workflow
- src/components: reusable frontend UI components
- src/lib: API clients, Supabase helpers, report generation, and utilities
- tests: unit and integration tests

## Notes

This project is designed as a practical AI research assistant rather than a full-scale financial platform. It demonstrates how multi-agent analysis, streaming UI, and LLM-driven synthesis can be combined into a usable investment research experience.
